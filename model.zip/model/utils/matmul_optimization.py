import numpy as np
import torch.nn as nn
import os
import ast
import sys

def minimize_operation_matrix(matrix, matrix_binarized = False, bit_size = 8):
    """
    Args:
        matrix: given m x n matrix
        bit_size: bit width of each element in the matrix
        matrix_binarized: flag to show whether matrix is already binarized or not
        
    Output:
        index_array: format of array is: [left#, right#, target#, 'operation'] 
            and first row is: [rows, cols, bit, 'parameters']
    """
    # bit_size = bit_size+1
    rows1, cols1 = matrix.shape 
    bin_max_length = cols1*bit_size*3
    bin_weight = cols1*bit_size
    
    if not matrix_binarized:
        bin_matrix_ext = np.zeros( (rows1, bin_max_length), dtype=np.uint8)
        # Element wise conversion of each element to binary number for 2^bit notation
        bin_matrix = ((matrix.reshape(-1, 1) & (2**np.arange(bit_size)[::-1])) != 0).astype(int)
        bin_matrix = bin_matrix.reshape(rows1, -1)
        # Copying elements of bin matrix to extended binarized matrix
        bin_matrix_ext[:,:bit_size*cols1] = bin_matrix
    else:
        bin_matrix_ext = matrix
    
    # find the number of max matching ones of input binary matrix
    max_matching = bin_matrix_ext.sum(axis=0).max()
  
    # process binary matrix
    rows2, cols2 = bin_matrix_ext.shape
    cnt = 0 #count number of matches
    add_count = [0]*rows2 #count number of additions 
    one_count = int(max_matching) #count number of one in column

    # the first row of index_array is to store required parameters, [rows, cols, bit_size, 'parameters']
    index_array = []
    index_array.append([rows1, cols1, bit_size,'parameters'])

    a = 1
    for i in range(bin_weight):
        if((i%bit_size)==0):
            #print("MEM[%d] = -(input_vector[%d] << %d);" %(i,a-1,a*bit_size-i-1))
            index_array.append([i,a-1,a*bit_size-i-1,'-<<'])
        else:
            #print("MEM[%d] = input_vector[%d] << %d;" %(i,a-1,a*bit_size-i-1))
            index_array.append([i,a-1,a*bit_size-i-1,'<<'])
        if((i+1)%bit_size==0):
            a+=1
    
    
    while(one_count >= 1):
        print("\n Max number of 1: %d" % one_count)
        i = 0
        # while(i < cols2 and bin_max_length > bin_weight+cnt):
        while(i < bin_matrix_ext.shape[1]): # and bin_max_length > bin_weight+cnt):
            # doubling the matrix size whenever it runs out of memory  
            if bin_max_length <= bin_weight+cnt+2: 
                print('Increasing matrix size, current bin_max_length:', bin_max_length, 'bin_weight:', bin_weight, 'cnt:', cnt)
                bin_max_length += bin_matrix_ext.shape[1]
                bin_matrix_ext = np.hstack((bin_matrix_ext, np.zeros((rows1, bin_matrix_ext.shape[1]), 
                                                            dtype=np.int32)))
                print('Increasing matrix size, updated bin_max_length:', bin_max_length)
            
            # print('i:', i, 'searching for col:', bin_matrix_ext[:,i])
            # print('one_count:', one_count, 'i:', i)
            if((np.sum(bin_matrix_ext[:,i]==1))>=one_count):
                matching_idx = ((bin_matrix_ext[:,i] @ bin_matrix_ext) == one_count).nonzero()[0]
                # print('matching_idx:', matching_idx)
                if len(matching_idx) > 1:
                    j = matching_idx[0] if i != matching_idx[0] else matching_idx[1]
                    # print('j:', j, 'found col:', bin_matrix_ext[:,j])
                    #print("MEM[%d] = MEM[%d] + MEM[%d];"%(bin_weight+cnt,i,j))
                    index_array.append([i,j,bin_weight+cnt,'+'])
                    bin_matrix_ext[:,bin_weight+cnt] = bin_matrix_ext[:,i]&bin_matrix_ext[:,j]
                    bin_matrix_ext[:,i] = bin_matrix_ext[:,i]&(~bin_matrix_ext[:,bin_weight+cnt])
                    bin_matrix_ext[:,j] = bin_matrix_ext[:,j]&(~bin_matrix_ext[:,bin_weight+cnt])

                    cnt += 1
                    add_count[rows2-one_count] += 1
                else:
                    i += 1
            else:
                i += 1
        
        if check_one_hot(bin_matrix_ext):
            break
        #print("Counts of Additions for %d one match:  %d" %(one_count,add_count[rows2-one_count]))
        one_count=one_count-1
    
    # Adding non zero operations at the end
    nonzero_row_cols = bin_matrix_ext.nonzero() 
    nonzero_rows = nonzero_row_cols[0]
    nonzero_cols = nonzero_row_cols[1]
    index_array = index_array + [[row, col, -1, '='] for row, col in zip(nonzero_rows, nonzero_cols)]
    
    return index_array, bin_matrix_ext

# matrix optimized multiplication between matrix and input_vector
def matrix_optimized_multiplier(index_array, input_vector):
    """
    Args:
        index_array: format of array is: [left#, right#, target#, 'operation'] 
            and first row is: [rows, cols, bit, 'parameters']
        input_vector: given n sized input
        
    Output:
        output_vector: resulting matrix multiplication of input_vector and 
            the index array reduced matrix. 
    """
    # define parameters
    rows1, cols1 = index_array[0][0], index_array[0][1]
    bit = index_array[0][2]    
    # mem_size = max(row[2] for row in index_array)
    mem_size = len(index_array)
    
    #initialize output vector
    output_vector = np.zeros(shape=(rows1, 1),dtype=np.int32)
    
    #initialize MEM
    MEM = np.zeros(shape=(mem_size+1),dtype=np.int32)
    
    # do calculations 
    # row format: [left_pos, right_pos, target#, 'operation'] 
    for row in index_array[1:]:
        # print(row)
        if row[2] != -1:
            if row[3] == '-<<':
                MEM[row[0]] = -1 * pow(2,row[2]) * input_vector[row[1]]
            elif row[3] == '>>':
                MEM[row[0]] = pow(2,-row[2]) * input_vector[row[1]]
            elif row[3] == '<<':
                MEM[row[0]] = pow(2,row[2]) * input_vector[row[1]]
            elif row[3] == '+':
                MEM[row[2]] = MEM[row[0]] + MEM[row[1]]
        else:
            # row[0] -> represents row, and row[1] represents columns
            # So basically here we are adding all the 1's column-wise
            output_vector[row[0]] += MEM[row[1]]
    
    return output_vector

def check_one_hot(matrix):
    return np.all(np.sum(matrix, axis=1) == 1)

def save_index_arrays(index_array, filename):
    """
    Args:
        index_array: format of array is: [left#, right#, target#, 'operation'] 
            and first row is: [rows, cols, bit, 'parameters']
        filename: file name with the path to store the index array
    """    
    if not os.path.exists('index_arrays'):
        os.makedirs('index_arrays')
    
    # Combine the folder name with the filename to create a full path
    full_path = os.path.join('index_arrays', filename)

    np.savetxt(full_path, index_array, fmt='%s')
    
def read_index_array(filename):
    """
    Args:
        filename: stored file name with the path to read the index array
    """
    dt = np.dtype('i4,i4,i4,U10')
    index_array = np.loadtxt(filename, dtype={'names': ['left', 'right', 'target', 'operation'],
                                                'formats': dt}) #, unpack=True)
    index_array = [list(op) for op in index_array.tolist()]
    return index_array

def prepare_model_index_arr(model, frac_bits = 20):
    """
    This function support index array preparation of only linear layers
    Args:
        model: provide a pytorch model
        frac_bits: given fractional bits for conversion from fixed point to integer values
        
    Outputs:
        index_arrays: list of index arrays for each linear layer in the model
    """
    index_arrays = []
    for layer in model.modules():
        if isinstance(layer, nn.Linear):
            print('Processing layer:', layer)
            W = layer.weight.cpu().detach().numpy() #.T
            weights = np.array(W * pow(2, frac_bits),dtype=np.int32)
            index_array, _ = minimize_operation_matrix(weights, bit_size = 32)
            index_arrays.append(index_array)
    return index_arrays

def inference_model(model, input_vectors, index_arrays, frac_bits = 20):
    """
    Args:
        model: provide a pytorch model
        input_vectors: list of given n sized input vectors
        index_array: format of array is: [left#, right#, target#, 'operation'] 
            and first row is: [rows, cols, bit, 'parameters']
        frac_bits: given fractional bits for conversion from fixed point to integer values
        
    Outputs:
        outputs: list of inferencing output given the model
    """
    outputs = []
    for i, input in enumerate(input_vectors):
        j = 0
        for layer in model.modules():
            if isinstance(layer, nn.Linear):
                # Index arrays are pre-calculated for linear layers
                # For first layer, input is the input vectors
                if j == 0:
                    int_out = matrix_optimized_multiplier(index_arrays[j], input)
                # For remaining of the layers, input is the output of previous layer
                else:
                    int_out = matrix_optimized_multiplier(index_arrays[j], int_out)            
                int_out = int_out.reshape(1, -1)[0] / pow(2, frac_bits)
                j += 1
                
            elif isinstance(layer, nn.BatchNorm1d):
                Gamma = layer.weight.cpu().detach().numpy()
                Beta = layer.bias.cpu().detach().numpy()
                mean = layer.running_mean.cpu().detach().numpy()
                var  = layer.running_var.cpu().detach().numpy()
                std = np.sqrt(var)
                th = ((-Beta)*std/Gamma) + mean
                # int_out = (int_out > thresholds[k]).astype(int) 
                int_out = (int_out > th).astype(int) 
                int_out[int_out == 0] = -1
                # k += 1
        
        outputs.append(np.argmax(int_out, axis=0))
    return outputs

# class FC_wrapper(FC):
#     """
#     This is a wrapper for pytorch model to get all intermediate outputs for each layer
#     """
#     def __init__(self, *args, **kwargs):
#         super().__init__(*args, **kwargs)

#     def forward(self, x):
#         out = []
#         for mod in self.features:
#             x = mod(x)
#             out.append(x)
#         return x, out
    
# def fc_redefined(cfg):
#     weight_bit_width = cfg.getint('QUANT', 'WEIGHT_BIT_WIDTH')
#     act_bit_width = cfg.getint('QUANT', 'ACT_BIT_WIDTH')
#     in_bit_width = cfg.getint('QUANT', 'IN_BIT_WIDTH')
#     num_classes = cfg.getint('MODEL', 'NUM_CLASSES')
#     in_channels = cfg.getint('MODEL', 'IN_CHANNELS')
#     out_features = ast.literal_eval(cfg.get('MODEL', 'OUT_FEATURES'))
#     net = FC_wrapper(
#         weight_bit_width=weight_bit_width,
#         act_bit_width=act_bit_width,
#         in_bit_width=in_bit_width,
#         in_channels=in_channels,
#         out_features=out_features,
#         num_classes=num_classes)
#     return net