import numpy as np
import os

def write_to_file(filename, code):
    if not os.path.exists('generated_C'):
        os.makedirs('generated_C')
    
    # Combine the folder name with the filename to create a full path
    full_path = os.path.join('generated_C', filename)

    with open(full_path, 'w') as file:
        file.write(code)

def generate_c_2d_array(python_2d_array):
    # Check if each row has the correct format: 3 integers followed by a string of up to 10 characters
    for row in python_2d_array:
        if not (len(row) == 4 and all(isinstance(x, int) for x in row[:-1]) and isinstance(row[-1], str)):
            raise ValueError("Incorrect format for some rows")

    c_rows = []
    for row in python_2d_array:
        c_row = f"{{ {row[0]}, {row[1]}, {row[2]}, \"{row[3]}\" }}"
        c_rows.append(c_row)
    c_array_values = ',\n'.join(c_rows)
    
    c_array_definition = f"static const RowType index_array[MEM_SIZE] = {{\n{c_array_values}\n}};\n"

    return c_array_definition

def codegen(index_array, filename):

    # The number of columns in our weight matrix is equal to the number of variables (n_rows) in the input_vector
    rows, n_variables, bit_size = index_array[0][0], index_array[0][1], index_array[0][2]

    # mem_size = max(row[2] for row in index_array)
    mem_size = len(index_array)
    
    c_code = ''''''

    # Define MEM and fill it values
    if bit_size >= 32 :     # long
        c_code += f'''
    long MEM[{mem_size}];
''' 
        c_code += f'''
    void matrixvectormul(long input_vector[], long output_vector[]){{
'''
    else :                  # int
        c_code += f'''
    int MEM[{mem_size}];
'''
        c_code += f'''
    void matrixvectormul(int input_vector[], int output_vector[]){{
''' 
    
    for row in index_array[1:]:
        if row[2] != -1:
            if row[3] == '-<<':
                # MUltiply first, then bitshift + 1 
                # int y = ~x + 1;  // y will be -42
                # MEM[row[0]] = -1 * pow(2,row[2]) * input_vector[row[1]]
                c_code += f'''
    MEM[{row[0]}] = -input_vector[{row[1]}] << {row[2]};'''
            elif row[3] == '>>':
                # MEM[row[0]] = pow(2,-row[2]) * input_vector[row[1]]
                c_code += f'''
    MEM[{row[0]}] = input_vector[{row[1]}] << {row[2]};'''
            elif row[3] == '<<':
                # MEM[row[0]] = pow(2,row[2]) * input_vector[row[1]]
                c_code += f'''
    MEM[{row[0]}] = input_vector[{row[1]}] << {row[2]};'''

            # Computing additions step
            elif row[3] == '+':
                # MEM[row[2]] = MEM[row[0]] + MEM[row[1]]
                c_code += f'''
    MEM[{row[2]}] = MEM[{row[0]}] + MEM[{row[1]}];'''
        else:
            # Result step
           #  row[0] -> represents row, and row[1] represents columns
           #  So basically here we are adding all the 1's column-wise
            # output_vector[row[0]] += MEM[row[1]]
            c_code += f'''
    output_vector[{row[0]}] = MEM[{row[1]}];'''
    c_code += """
    return ;
}
"""

    # # Write to folder 
    # if not os.path.exists('generated_C'):
    #     os.makedirs('generated_C')
    
    # Combine the folder name with the filename to create a full path
    # full_path = os.path.join('generated_C', 'generated_C_' + filename+ '.c')

    write_to_file(f'generated_C_{filename}.c', c_code)
    return c_code
